package timestamp;

import java.text.SimpleDateFormat;
import java.util.Date;

public class CurrentTime {

	public static void main(String[] args) {
		
		Date currentDate =new Date();
		System.out.println(currentDate);
		System.out.println();
		
		//hh:mm:ss fomat
		SimpleDateFormat timeformat=new SimpleDateFormat("HH:mm:ss"); //mm-->minute & HH ->for 24hr format & hh->for 12hr format
		System.out.println(timeformat.format(currentDate));
		
		//MM/dd/yyyy fomat
		SimpleDateFormat dateformat=new SimpleDateFormat("MM/dd/yyyy"); //MM--> MONTH
		System.out.println(dateformat.format(currentDate));
		
		//day name the week
		SimpleDateFormat dayofTheWeek = new SimpleDateFormat("EE"); //"EEEE"-->Tuesday
		System.out.println(dayofTheWeek.format(currentDate));
		
		//clock format
		SimpleDateFormat clockformat = new SimpleDateFormat("hh:mm:a");
		System.out.println(clockformat.format(currentDate));
		
		//24hr clock format
		SimpleDateFormat clockformat2 = new SimpleDateFormat("kk:mm:a");
		System.out.println(clockformat2.format(currentDate));

	}

}
