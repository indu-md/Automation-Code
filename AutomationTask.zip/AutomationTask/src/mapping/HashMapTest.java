package mapping;

import java.util.HashMap;

public class HashMapTest {

	public static void main(String[] args) {
		HashMap<String,String> value=new HashMap<String,String>();
		value.put("kenny@hcl.com", "Asdf!123");
		value.put("rozita@hcl.com", "qwer@321");
		value.put("berlin@xyz.com","zxcv123");
		
		//value.remove("kenny@hcl.com"); //remove value using hashmap
		value.replace("berlin@xyz.com", "zxcv123", "aaaaaa");  //replace old value to new value
		
		//System.out.println(value.containsValue("qwer@321")); //find value which returns true or false
		//System.out.println(value.size());  //we can find size
		
		//System.out.println(value.keySet());  //[kenny@hcl.com, rozita@hcl.com, berlin@xyz.com]
		
		System.out.println(value);

	}

}
