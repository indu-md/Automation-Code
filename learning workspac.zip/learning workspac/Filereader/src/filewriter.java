import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class filewriter {

	public static void main(String[] args) throws IOException {
		
		
		File file=new File("C:\\Software\\Training\\writer.txt"); 
		FileWriter fw=new FileWriter (file);
		PrintWriter pw =  new PrintWriter(fw);
		int i;
		for(i=1;i<=10;i++)
		{
		pw.println("testing");
		pw.println("automation");
		pw.println("indu");
		}
		pw.close();
	}

}
