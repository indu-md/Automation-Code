import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Scanner;

public class FileReader {

	public static void main(String[] args) throws IOException {

		File file = new File("C:\\Software\\Training\\reader.txt"); 
		Scanner scan = new Scanner(file); //scanning every line
		
		//String fileContent="copy file:";
		while(scan.hasNextLine()) {
		System.out.println(scan.nextLine()); //reading 1st line of the file
		//fileContent = fileContent.concat(scan.nextLine() + " \n " );
		}
	//FileWriter writer = new FileWriter ("C:\\Software\\Training\\copyreader.txt");
	//writer.write(fileContent);
	//writer.close();
	
}
}