package mapping;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Genricmap {
	
public static Map<String, object[]> map =null;

public static String readvaluefrommap(Map<String, Object[]> map, String dept) {
	
	Object[]  obj=map.keySet().toArray();
	ArrayList<Object> object = new ArrayList<Object>(Arrays.asList(obj));
	Object[] v;
	
	v = (Object[]) map.get(obj(object.indexOf(dept));
	
	
}
public static void main(String[] args) {
		
		map = readTestData("tc1","main");
		String id=readvaluefrommap("map","id");
		
		
		Map<String, Integer> map=new HashMap<String, Integer>();
		map.put("AAAA",101);
		map.put("BBBB",102);
		map.put("CCCC",103);
		
		for(Map.Entry<String, Integer> entry:map.entrySet()) {	//
		
			
			System.out.println(entry.getKey() + " = " + entry.getValue());
			
		}
		
		
	

	}

}
