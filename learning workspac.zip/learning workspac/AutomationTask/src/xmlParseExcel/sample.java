package xmlParseExcel;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class sample{
	
public static final String EXCELFILELOCATION= "C:\\Software\\learning workspac\\Evidence\\ExcelToXml\\Test.xlsx";
private static FileInputStream fis;
 private static XSSFWorkbook workbook;
 private static XSSFSheet sheet;
 private static XSSFRow row;
 private static XSSFCell cell;
 
 public static void loadExcel() throws Exception{
	 	
	 File file = new File(EXCELFILELOCATION);
	 fis=new FileInputStream(file);
	 workbook = new XSSFWorkbook(fis);
	 sheet=workbook.getSheet("Test");
	 fis.close();
	 
 }
 	
 		public static Map<String, Map<String,String>> data() throws Exception{
 			if(sheet==null) {
 				loadExcel();
 			}
 			
 			Map<String,Map<String,String>> supermap = new HashMap<String,Map<String, String>>();
 			Map<String, String> mymap = new HashMap<String, String>();
 			
 			int r=sheet.getLastRowNum()+1;
 			row=sheet.getRow(0);
 			int c=row.getLastCellNum();
 			
 			for(int i=0;i<c ;i++) {
 				row=sheet.getRow(0);
 				String keycell=row.getCell(i).getStringCellValue();
 				
 				for(int j=1;j<c;j++) {
 					cell=row.getCell(i);
 	 				String rowheader=cell.getStringCellValue();
 	 				mymap.put(keycell, rowheader);	
 				}
 				
 				supermap.put("Data", mymap);
 				
 			}
 		
			return supermap;
 			
 		} 

 		public static String getValue(String key) throws Exception{
 			 Map<String, String> myval = data().get("Data");
 			 String retrive = myval.get(key);
 			return retrive;
 			 
 		 }

 		public static void main(String[] args) throws Exception {
 			 
 			System.out.println(getValue("TC SL"));
 			System.out.println(getValue("Description"));
 			System.out.println(getValue("Value"));
 			System.out.println(getValue("Title"));
 			System.out.println(getValue("Browser"));
 			System.out.println(getValue("Platform"));
 		}
 	}
