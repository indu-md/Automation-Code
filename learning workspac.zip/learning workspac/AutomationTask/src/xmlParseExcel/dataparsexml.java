package xmlParseExcel;

public class dataparsexml {

	public static void main(String[] args) throws Exception {
		    exceldata obj=new exceldata();
		
			//System.out.println(obj.readalldata());
		   
		   

			
			//System.out.println(obj.getValue("TC SL"));
			//System.out.println(obj.getValue("Description"));
			//System.out.println(obj.getValue("Value"));
			//System.out.println(obj.getValue("Title"));
			//System.out.println(obj.getValue("Browser"));
			//System.out.println(obj.getValue("Platform"));
			//obj.CreateXmlFile();
			//obj.readxml();
			//obj.count();
			
		}

	}


