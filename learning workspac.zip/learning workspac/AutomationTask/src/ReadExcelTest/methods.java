package ReadExcelTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.formula.functions.Value;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class methods {
	
	public void reading() throws Exception {
		
		
		FileInputStream f=new FileInputStream(new File("C:\\Software\\learning workspac\\Evidence\\read.xlsx"));  
		XSSFWorkbook wb=new XSSFWorkbook(f);   
		XSSFSheet sheet=wb.getSheetAt(0);  
		
		Iterator<Row> it = sheet.iterator();
		while(it.hasNext()) {
			Row row = it.next();
				Iterator<Cell> cellit = row.cellIterator();
				while(cellit.hasNext()) {
					Cell cell=cellit.next();
					
					switch (cell.getCellTypeEnum()) {
						case STRING:
							System.out.println(cell.getStringCellValue() + "       " );
						    break;
						case NUMERIC:
							System.out.println("       "+cell.getNumericCellValue() + "      ");
							break;
						default:
							break;
					}
				}
				
			System.out.println("");
		}
		
	}
	
	public String getdata(int row, int cell) throws Exception {
		
		FileInputStream f=new FileInputStream(new File("C:\\Software\\learning workspac\\Evidence\\read.xlsx"));  
		XSSFWorkbook wb=new XSSFWorkbook(f);   
		XSSFSheet sheet=wb.getSheetAt(0);  
		String value=null;
		Row r =sheet.getRow(row);
		Cell c=r.getCell(cell);
		value=c.getStringCellValue();
		return value;
				
				
	}
	
	public void update() throws Exception {
		
		String filepath="C:\\Software\\learning workspac\\Evidence\\read.xlsx";
		File file=new File(filepath);
		FileInputStream fi=new FileInputStream(file);  
		XSSFWorkbook wb=new XSSFWorkbook(fi);   
		XSSFSheet sheet=wb.getSheet("Sheet1");
		
		XSSFRow r = sheet.getRow(0);
		 XSSFCell c = r.createCell(2); 
		 c.setCellValue("CAPITALS");
		
		 XSSFRow r1 = sheet.getRow(1);
		 XSSFCell c1 = r1.createCell(2); 
		 c1.setCellValue("Dublin");
		 
		 XSSFRow r2 = sheet.getRow(2);
		 XSSFCell c2 = r2.createCell(2); 
		 c2.setCellValue("Mumbai"); 
		 
		 XSSFRow r3 = sheet.getRow(3);
		 XSSFCell c3 = r3.createCell(2); 
		 c3.setCellValue("London"); 
		 
		 XSSFRow r4 = sheet.getRow(4);
		 XSSFCell c4 = r4.createCell(2); 
		 c4.setCellValue("Berlin");
//		
//		sheet.getRow(1).createCell(2).setCellValue("Capital");
//		sheet.getRow(2).createCell(2).setCellValue("Dublin");
//		sheet.getRow(3).createCell(2).setCellValue("Mumbai");
//		sheet.getRow(4).createCell(2).setCellValue("London");
//		sheet.getRow(5).createCell(2).setCellValue("Berlin");
		
		FileOutputStream fo = new FileOutputStream(filepath);
		wb.write(fo);
			fo.close();	
		
	}
	
	public void fullupdate() throws Exception {
		
		String filepath="C:\\Software\\learning workspac\\Evidence\\read.xlsx";
		File file=new File(filepath);
		FileInputStream fi=new FileInputStream(file);  
		XSSFWorkbook wb=new XSSFWorkbook(fi); 
		XSSFSheet sheet=wb.createSheet("meeting");
		System.out.println("sheet created" );
		
		Map<String, Object[]> data = new HashMap<String, Object[]>();
		
		data.put("1", new Object[] { "EMPID", "NAME", "DESIGNATION"});
		data.put("2", new Object[] { "1", "Rozita", "Test"});
		data.put("3", new Object[] { "2", "Abreham", "Dev"});
		data.put("4", new Object[] { "3", "Grim", "Sup"});
		data.put("5", new Object[] { "4", "Lori", "Manage"});
		
		Set<String> s = data.keySet();
		int rowcount=0;
		for(String key : s) {
			Row row=sheet.createRow(rowcount++);
			Object[] objarr = data.get(key);
				int columncount=0;
				for(Object value : objarr) {
					Cell cell=row.createCell(columncount++);
						if(value instanceof String) 
							cell.setCellValue((String)value);
						else if(value instanceof Integer)
							cell.setCellValue ((Integer)value);
				}
		
							
				
			}
				FileOutputStream fo = new FileOutputStream(filepath);
				wb.write(fo);
				fo.close();		
				
			}
			
		}
		
		

