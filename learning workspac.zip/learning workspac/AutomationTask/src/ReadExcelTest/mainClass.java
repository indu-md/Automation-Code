package ReadExcelTest;

public class mainClass {

	public static void main(String[] args) throws Exception {

		methods m = new methods();
		//System.out.println("Reading Excel Sheet value:");
		//m.reading();
		//String out=m.getdata(1,1);
		//System.out.println("The particular cell value is"  + "     "  +  out);
		
		
//		m.update();
//		System.out.println("Data has been updated successfully");
		
		m.fullupdate();
		System.out.println("data has updated ");

	}

}
