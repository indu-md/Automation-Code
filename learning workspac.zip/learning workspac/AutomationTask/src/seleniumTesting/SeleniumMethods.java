package seleniumTesting;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.google.common.io.Files;

import org.openqa.selenium.TakesScreenshot;

public class SeleniumMethods {
	
	public  void TakescreenShot() throws Exception {
		
		System.setProperty("webdriver.ie.driver","C:\\Software\\IEDriverServer_x64_2.48.0\\IEDriverServer.exe");
		WebDriver driver=new InternetExplorerDriver(); 
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.navigate().to("https://www.seleniumeasy.com/test/bootstrap-date-picker-demo.html");
		
		TakesScreenshot ts= (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		Files.copy(source, new File("C:\\Software\\learning workspac\\Evidence\\Screen.png"));
		System.out.println("Screenshot has taken");
		//driver.quit();
		
	}
	
	
	public void selectCalendar() throws Exception {
		String today;
		
		System.setProperty("webdriver.ie.driver","C:\\Software\\IEDriverServer_x64_2.48.0\\IEDriverServer.exe");
		WebDriver driver=new InternetExplorerDriver(); 
		driver.manage().window().maximize();
		driver.navigate().to("https://www.seleniumeasy.com/test/bootstrap-date-picker-demo.html");
		
		 today=getCurrentDay();
		 
		 System.out.println("today date & month is" + today + "      " );
		
		driver.findElement(By.xpath("//*[@id=\"sandbox-container1\"]/div/span/i")).click();
		
		List<WebElement> columns=driver.findElements(By.tagName("td"));

		for (WebElement cell: columns){
		   
		       if(cell.getText().equals(today)) {
		    	  cell.click();
		    	  System.out.println("today date clicked");
		      }
		     
		      
		      break;
		   }
		 
	
		
			}
	

//		 }
	
	public  String getCurrentDay() {
		
		Calendar cal = Calendar.getInstance(TimeZone.getDefault());
		
		int todayi= cal.get(Calendar.DAY_OF_MONTH);

		
		String todaystr = Integer.toString(todayi);
//		System.out.println("Today in String " +todaystr + "    ");
		return todaystr;
	}
	
	public String getCurrentMonth() {
		Date currentDate =new Date();
		SimpleDateFormat month=new SimpleDateFormat("MMMM");
		
		String m = month.format(currentDate).toString();
		return m;
		
	}
	
	public void Test() {

		System.setProperty("webdriver.ie.driver","C:\\Software\\IEDriverServer_x64_2.48.0\\IEDriverServer.exe");
		WebDriver driver=new InternetExplorerDriver(); 
		driver.manage().window().maximize();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		driver.get("https://www.seleniumeasy.com/test/bootstrap-date-picker-demo.html");
		driver.findElement(By.xpath("//*[@id=\"sandbox-container1\"]/div/span/i")).click();
		WebElement button =driver.findElement(By.className("today.day"));
		
		js.executeScript("arguments[0].click();", button);
		System.out.println("clicked");
		
	}

}
