package seleniumTesting;

public class AutomationTest {

	public static void main(String[] args) throws Exception {
		
		SeleniumMethods sm=new SeleniumMethods();
		//sm.TakescreenShot();
//		sm.selectCalendar();
		//sm.getCurrentMonth();
		sm.Test();

	}

}
