package tostringlearn;

public class mainclass {

	public static void main(String[] args) {
		
		employee e1 =new employee(1,"eee");
		employee e2 =new employee(2,"rrrr");
		System.out.println(e1);
		System.out.println(e2);

	}

}
