package tostringlearn;

public class employee {
	
	int empid;
	String name;
	public employee(int empid, String name) {
		
		this.empid = empid;
		this.name = name;
	}
	
	public String toString() {
		return empid +" " + name;
	}

}
