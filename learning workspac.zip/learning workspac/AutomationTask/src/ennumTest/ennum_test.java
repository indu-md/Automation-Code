package ennumTest;

import java.util.Scanner;

//enum levels {  //enum do not have type only it has list or label ; things do not change
//	
//	LOW,MEDIUM,HIGH;
//}

public class ennum_test {
	
	enum Flavour{
		CHOCOLATE, VANILLA, STRAWBERRY;
		
//		public static void getvanila() {
//			System.out.println(Flavour.VANILLA);
//		}
	}

	public static void main(String[] args) {
//		Scanner obj = new Scanner(System.in);
//		System.out.println("enter you favourite");
//		
//		String f = obj.nextLine();
		Flavour f=Flavour.CHOCOLATE;
		
		if(f == f.CHOCOLATE) {
			System.out.println("it is chocolate"  +  f);	
		}
		else if(f ==f.STRAWBERRY){
			System.out.println("it is strawberry");
					}
		else if(f ==f.VANILLA) {
			System.out.println("it  is vanilla!!!");
		}
	}   

	
		

	}


//public static void main(String[] args) {
//	levels l =levels.LOW;
//	
//	System.out.println(l);
//	
//	switch(l) {
//	case LOW:
//		System.out.print("low level");
//		break;
//	case MEDIUM:
//		System.out.print("medium level");
//		break;
//	case HIGH:
//		System.out.print("high level");
//		break;	