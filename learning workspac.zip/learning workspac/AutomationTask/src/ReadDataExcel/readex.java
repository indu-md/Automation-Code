package ReadDataExcel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class readex {

	public static void main(String[] args) throws Exception {
		
		File src = new File("C:\\Software\\learning workspac\\data.xlsx");
		FileInputStream fs = new FileInputStream(src);
		XSSFWorkbook wb = new XSSFWorkbook(fs); //total workbook will load
		XSSFSheet sheet1=  wb.getSheetAt(0); //load sheet 0->focus from sheet1 1->focus from sheet 2 and so on
		
		int rowcount = sheet1.getLastRowNum();
		
		Iterator<Row> itr = sheet1.iterator();    //iterating over excel file  
		while (itr.hasNext())                 
		{  
		Row row = itr.next();  
		Iterator<Cell> cellIterator = row.cellIterator();   //iterating over each column  
		while (cellIterator.hasNext())   
		{  
		Cell cell = cellIterator.next();  
		switch (cell.getCellTypeEnum())               
		{  
		case STRING:
		System.out.println(cell.getStringCellValue() + "\t\t\t");
		break;
		//case NUMERIC:    //field that represents number cell type  
		//System.out.println(cell.getLocalDateTimeCellValue() + "\t\t\t");
		//break; 
//		case BOOLEAN:    //field that represents string cell type  
//		System.out.print(cell.getBooleanCellValue() + "\t\t\t");  
//		break; 
		default:  
		}  
		}  
		System.out.println("");  
		}  
		}  

}


	
	


//for(int i=0; i<=rowcount;i++) {
//String data0 = sheet1.getRow(0).getCell(0).getStringCellValue();
//System.out.println("Data from excel is" + data0);