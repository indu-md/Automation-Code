package ReadDataExcel;

import javax.xml.crypto.Data;

import org.apache.poi.ss.usermodel.Cell;

public class readexcel {

	public static void main(String[] args) {
		
		ExcelDataConfig cfg = new ExcelDataConfig("C:\\Software\\learning workspac\\data.xlsx");
		
	
		
		System.out.println(cfg.gespecifictData(0, 1, 1));
		//System.out.println(cfg.getvalue(Cell));
		return cfg.getvalue(c);

	}

}
