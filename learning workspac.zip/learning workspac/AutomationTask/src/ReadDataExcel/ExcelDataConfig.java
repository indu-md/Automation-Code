package ReadDataExcel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelDataConfig {
	XSSFWorkbook wb;
	XSSFSheet sheet1;
	FileInputStream fs;
	public ExcelDataConfig(String excelpath) {
		

		try {
			File src = new File(excelpath);
			 fs = new FileInputStream(src);
			 wb = new XSSFWorkbook(fs); //total workbook will load
			 
		} 
		catch (Exception e) {
			
			System.out.println(e.getMessage());
		} 
	}


public String gespecifictData(int sheetnumber, int row, int column) 
{	
	sheet1=  wb.getSheetAt(sheetnumber);
	
	 
	String data = sheet1.getRow(row).getCell(column).getStringCellValue();
	return data;
	
}

public void getvalue(Cell c) {
	
	Iterator<Row> itr = sheet1.iterator();    //iterating over excel file  
	while (itr.hasNext())                 
	{  
	Row row = itr.next();  
	Iterator<Cell> cellIterator = row.cellIterator();   //iterating over each column  
	while (cellIterator.hasNext())   
	{  
	Cell cell = cellIterator.next();  
	switch (cell.getCellTypeEnum())               
	{  
	case STRING:
	System.out.println(cell.getStringCellValue() + "\t\t\t");
	break;
	
	default:  
	}  
	}  
	System.out.println("");  
	}  
	}  
	}
	


