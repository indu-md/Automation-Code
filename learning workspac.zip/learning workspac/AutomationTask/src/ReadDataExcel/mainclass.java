package ReadDataExcel;

public class mainclass {

	public static void main(String[] args) throws Exception {
		readTest rt = new readTest();
		System.out.println(" " + rt.read(null));
	}
}