package ExcelToXml;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class readalldata {
	
	public static final String EXCELFILELOCATION= "C:\\Software\\learning workspac\\Evidence\\ExcelToXml\\Test.xlsx";
	 
	 private static FileInputStream fis;
	 private static XSSFWorkbook workbook;
	 private static XSSFSheet sheet;
	 private static XSSFRow row;
	 
	 public static void loadExcel() throws Exception{
		 	
		 File file = new File(EXCELFILELOCATION);
		 fis=new FileInputStream(file);
		 workbook = new XSSFWorkbook(fis);
		 sheet=workbook.getSheet("Test");
		 fis.close();
		 
	 }
	
	 public static Map<String,Map<String, String>> getDataMap() throws Exception{
		 if(sheet==null) {
			 loadExcel();
		 }
		 
		 Map<String,Map<String, String>> superMap = new HashMap<String, Map<String, String>>(); //it return entire map
		 Map<String, String> myMap =new HashMap<String,String>();
		 
		 for(int i=1;i<sheet.getLastRowNum()+1;i++) {
			
			 row=sheet.getRow(i); 
		     String keycell=row.getCell(0).getStringCellValue();
		     
		     	int colnum =row.getLastCellNum() ;
		         for(int j=1;j<colnum;j++) {
		     		String value = row.getCell(j).getStringCellValue();
		     		myMap.put(keycell, value);
		     		
		     	}
		     	superMap.put("Data",myMap );
		 }
		 return superMap;
		 
	 }
	 
	 public static String getValue(String key) throws Exception{
		 Map<String, String> myval = getDataMap().get("Data");
		 String retrive = myval.get(key);
		return retrive;
		 
	 }

	public static void main(String[] args) throws Exception {
		 
		System.out.println(getValue("TC005"));
	}
}
