package ExcelToXml;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class mainclass {
	static String xpath="C:\\Software\\learning workspac\\Evidence\\ExcelToXml\\Test.xml";

	public static void main(String[] args) throws Exception {
		
		
		
		methods obj=new methods();
		//obj.readrow("C:\\Software\\learning workspac\\Evidence\\ExcelToXml\\Test.xlsx");
		//obj.readxml();
		obj.CreateXmlFile();
		
//		String path = obj.readrow("C:\\Software\\learning workspac\\Evidence\\ExcelToXml\\Test.xlsx");
		 DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		 DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		 Document doc = dBuilder.newDocument();
		         
		         // root element
		 Element rootElement = doc.createElement("note");
		 doc.appendChild(rootElement);

		         

		         // Description element
//		         Element d = doc.createElement("Description");
//		        
//		         d.appendChild(doc.createTextNode("{" + obj.sv + "}"));
//		         rootElement.appendChild(d);

		         Element v = doc.createElement("Value");
		         v.appendChild(doc.createTextNode("{" + "}"));
		         rootElement.appendChild(v);
		         
		         Element t = doc.createElement("Title");
		         t.appendChild(doc.createTextNode("{" + "}"));
		         rootElement.appendChild(t);
		         
		         Element bo = doc.createElement("Body");
		         bo.appendChild(doc.createTextNode("{" +  "}"));
		         rootElement.appendChild(bo);
		         
		         Element b = doc.createElement("Base");
		         b.appendChild(doc.createTextNode("{" +"}"));
		         rootElement.appendChild(b);

		         // write the content into xml file
//		         TransformerFactory transformerFactory = TransformerFactory.newInstance();
//		         Transformer transformer = transformerFactory.newTransformer();
//		         DOMSource source = new DOMSource(doc);
//		         StreamResult result = new StreamResult(new File("C:\\Software\\learning workspac\\Evidence\\ExcelToXml\\testingout.xml"));
//		         transformer.transform(source, result);
//		         
//		         
//		         StreamResult consoleResult = new StreamResult(System.out);
////		         transformer.transform(source, consoleResult);
		
		
		
		}

		
		

	}
