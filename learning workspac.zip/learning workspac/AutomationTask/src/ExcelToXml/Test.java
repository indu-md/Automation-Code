package ExcelToXml;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFFactory;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Test {
	
	 public static final String EXCELFILELOCATION= "C:\\Software\\learning workspac\\Evidence\\ExcelToXml\\Test.xlsx";
	 
	 private static FileInputStream fis;
	 private static XSSFWorkbook workbook;
	 private static XSSFSheet sheet;
	 private static XSSFRow row;
	 
	 
	 public static void loadExcel() throws Exception{
		 	
		 File file = new File(EXCELFILELOCATION);
		 fis=new FileInputStream(file);
		 workbook = new XSSFWorkbook(fis);
		 sheet=workbook.getSheet("Test");
		 fis.close();
		 
	 }
	 
	
	 public static List<Map<String, String>> readalldata() throws Exception{
		 if(sheet==null) {
			 loadExcel();
		 }
		 
		 
		 List<Map<String,String>> maplists = new ArrayList<>();

		 int rows= sheet.getLastRowNum();
		 row=sheet.getRow(0); 

		     for(int j=1;j<row.getLastCellNum();j++) {

		    	 Map<String, String> myMap = new HashMap<>();

		    	 for(int i=1;i<rows+1;i++) {
		    		 Row r=CellUtil.getRow(i, sheet);
		    		 String key = CellUtil.getCell(r, 0).getStringCellValue();
		    		// String key = r.getCell(0).getStringCellValue();
		    		 String value = CellUtil.getCell(r, j).getStringCellValue();//map each head
		    		 
		    		 myMap.put(key, value);
		     }
		    	 maplists.add(myMap);
		     }
		    
		 
		 
		 
		return maplists; 
		 
	 }

	 public static String getValue(String key) throws Exception{
		 Map<String, String> myval = readalldata().get(4);
		 String retrive = myval.get(key);
		return retrive;
		 
	 }
	 

	 
	 public static void main(String[] args) throws Exception {
		//System.out.println(readalldata());
		 System.out.println(getValue("TC005"));
		
		
	}
	 
}