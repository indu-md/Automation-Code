package GenricClass;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class mapArray{

	public static final String EXCELFILELOCATION= "C:\\Software\\learning workspac\\Evidence\\ExcelToXml\\Test.xlsx";
	 
	 private static FileInputStream fis;
	 private static XSSFWorkbook workbook;
	 private static XSSFSheet sheet;
	 private static XSSFRow row;
	 
    public static void loadExcel() throws Exception
    {
    	File file = new File(EXCELFILELOCATION);
		 fis=new FileInputStream(file);
		 workbook = new XSSFWorkbook(fis);
		 sheet=workbook.getSheet("Test");
		 fis.close();
    }
   
    public static Map<String, Map<String, Integer>> getDataMap() throws Exception{
    	
    	if(sheet==null) {
    		loadExcel();
    	}
    	
    	Map<String,Map<String, Integer>> superMap = new HashMap<String, Map<String, Integer>>(); //it return entire map
		Map<String, Integer> myMap =new HashMap<String,Integer>();
		
            XSSFSheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rows = sheet.rowIterator ();
    		
    		while (rows.hasNext ())
    		{
    			Row r=rows.next();
    			Iterator<Cell> cellit = r.cellIterator();
    			
    			HashMap<String, Integer> map = new HashMap<String, Integer>();
    			while(cellit.hasNext()) {
    				Cell cell=cellit.next();
    				
    				switch (cell.getCellTypeEnum()) {
    					case STRING:
    						 System.out.println(cell.getStringCellValue() + "       " );
    						String keycell=cell.getStringCellValue();
    						
    					    break;
    					case NUMERIC:
    						System.out.println("       "+cell.getNumericCellValue() + "      ");
    						Integer value=(int) cell.getNumericCellValue();
    						break;
    					default:
    						break;
    						 myMap.put(keycell, value);
    		
    				
    				
    				}
    				 
    			
    		}
    		
    		System.out.println("");
    		superMap.put("Data", myMap);
    		
    		return superMap;}
    
    		}	}
    		    

      public static Integer getValue(String key) throws Exception {
    	  
    	Map<String, Integer> val =getDataMap().get("Data");
    	Integer retrive =val.get(key);
		return retrive;
    	  
      }
    
       
	public static void main(String[] args) throws Exception {
			System.out.println(getValue("TC005"));
	}
    
}