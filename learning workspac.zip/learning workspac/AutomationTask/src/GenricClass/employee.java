package GenricClass;

public class employee<name,dept> {
	
	private  name n[];
	private  dept d[];
	public name[] getN() {
		return n;
	}
	public void setN(name[] n) {
		this.n = n;
	}
	public dept[] getD() {
		return d;
	}
	public void setD(dept[] d) {
		this.d = d;
	}
	public void put(String name, String dept) {
		// TODO Auto-generated method stub
		
	}
}
