package GenricClass;

import java.util.Map;

public class genricClasstest {

	public static void main(String[] args) {
		employee<String, String> e=new employee<String, String>();
		e.put("indu", "testing");
		e.put("yash", "devops");
		//for(Map.Entry<String,String> entry:e.entrySet())
		System.out.println("name =" + e.getD());
		System.out.println("department =" + e.getN());
		 

	}

}
