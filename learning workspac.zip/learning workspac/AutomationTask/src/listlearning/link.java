package listlearning;

import java.util.Iterator;
import java.util.LinkedList;

public class link {

	public static void main(String[] args) {
		LinkedList<Integer> link = new LinkedList<Integer>();
		
		link.add(4);
		link.add(5);
		link.add(5);
		link.add(43);
		
		//link.getFirst();
		
		//System.out.println(link.get(3));
		
		Iterator it = link.iterator();
		while(it.hasNext()) {
			if((int) it.next()==5) {
				System.out.println("we found 4");
			}
		}
	}

}
