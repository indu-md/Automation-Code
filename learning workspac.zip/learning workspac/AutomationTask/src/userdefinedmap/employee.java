package userdefinedmap;

public class employee {

		private String department;
		private String name;
		public employee(String string, String name) {
			super();
			this.department = string;
			this.name = name;
		}
		public String getdepartment() {
			return department;
		}
		public void setdepartment(String department) {
			this.department = department;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		
		
	
}
