package userdefinedmap;

import java.util.HashMap;
import java.util.Map;

public class HashmapUserdefined {

	public static void main(String[] args) {
		
		HashMap<String, Object[]> map=new HashMap <String, Object[]>();
		
		map.put("xyz", 123);
		
		HashMap<String, employee> map=new HashMap();
		map.put("user1",emp1);
		map.put("user2",emp2);
		map.put("user3",emp3);
		
		for(Map.Entry<String,employee> entry :map.entrySet()) {
			
			System.out.println(entry.getKey() + "______" + entry.getValue());
		}

	}

}
