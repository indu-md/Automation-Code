package ClickElement;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class clickelement {

	public static void main(String[] args) {
		
		 System.setProperty("webdriver.ie.driver","C:\\Software\\IEDriverServer_x64_2.48.0\\IEDriverServer.exe");
		 WebDriver driver=new InternetExplorerDriver();
		 driver.get("http://www.seleniumframework.com/Practiceform/");
		 driver.manage().window().maximize();
		 
		 //send key & click element
		driver.findElement(By.xpath("//*[@id=\"text-11\"]/div/form/p[2]/input")).sendKeys("indu");
		WebElement element = driver.findElement(By.xpath("//*[@id=\"text-11\"]/div/form/input[3]"));
		click(element,driver);
		 
		 
	}
		 public static void click(WebElement element, WebDriver driver) {
			 
			 JavascriptExecutor js = (JavascriptExecutor)driver;
			 js.executeScript("arguments[0].click();",element);
			 System.out.println("clicked");
			 
			

		 }
		 		 
	
	}


