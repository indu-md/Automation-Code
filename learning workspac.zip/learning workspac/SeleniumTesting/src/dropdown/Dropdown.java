package dropdown;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

public class Dropdown {

	public static void main(String[] args) {
		
		//System.setProperty("webdriver.edge.driver","C:\\Software\\Microsoft edge\\MicrosoftWebDriver.exe");
		//WebDriver driver=new EdgeDriver();  
		
		System.setProperty("webdriver.ie.driver","C:\\Software\\IEDriverServer_x64_2.48.0\\IEDriverServer.exe");
		WebDriver driver=new InternetExplorerDriver();  
		
		driver.navigate().to("http://demo.guru99.com/test/newtours/register.php");
		System.out.println("page opened");
		
		driver.manage().window().maximize();
		
		Select dropdown = new Select(driver.findElement(By.xpath("//select[@name='country']")));  
		dropdown.selectByVisibleText("INDIA"); 
		dropdown.selectByValue("INDIA");
		System.out.println("successfully selected");
		
	}

}
