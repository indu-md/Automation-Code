import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class SwitchToLastWindow {
	public static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		 System.setProperty("webdriver.ie.driver","C:\\Software\\IEDriverServer_x64_2.48.0\\IEDriverServer.exe");
		 WebDriver driver=new InternetExplorerDriver();
		 driver.manage().window().maximize();
		 driver.get("http://www.seleniumframework.com/Practiceform/");
		 
		 System.out.println("parent window"   + driver.getTitle());
		 
		
		 WebElement separate =driver.findElement(By.xpath("//*[@id=\"button1\"]"));
		 separate.click();
		 
		 driver.manage().window().maximize();
		 
		 Thread.sleep(3000);

		 Set<String> windowid = driver.getWindowHandles();
		 Iterator<String> it= windowid.iterator();
		 
		 String parentwindow=it.next();
		 String childwindow=it.next();
		 
		 driver.switchTo().window(childwindow);
		  	 
		 System.out.println("child window"   + driver.getTitle());
		
	
	}
//	public static void switchwindow(int index) {
//				
//				String windowiId=null;
//		Set<String> windowiIds = driver.getWindowHandles();
//		  Iterator<String> it=windowiIds.iterator();
//			
//				for(int i=1;i<=index;i++) {
//					windowiId=it.next();
//				}
//			driver.switchTo().window(windowiId);
//				
//			} 
		 
		 
}



