package ParentWindow;

import java.awt.Desktop.Action;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Parentwindow {
	
	static WebDriver driver;
	
	public static void main(String[] args) throws InterruptedException  {
		
		System.setProperty("webdriver.ie.driver","C:\\Software\\IEDriverServer_x64_2.48.0\\IEDriverServer.exe");
		WebDriver driver=new InternetExplorerDriver();
		driver.manage().window().maximize();
		driver.get("http://www.seleniumframework.com/Practiceform/");
		Set<String> parentwindow = driver.getWindowHandles ();
		
		System.out.println("parent tab"   + driver.getTitle());
		
		//String newtab = Keys.chord(Keys.CONTROL,Keys.RETURN);   //create new tab
		driver.findElement(By.xpath("//*[@id=\\\"button1\\\"]")).click();
		driver.manage().window().maximize();
		switchtab(parentwindow); 
	    System.out.println("child tab" + driver.getTitle());
	    
	    Thread.sleep(5000);
	  		
//		it iterate 2times and go to child
		

	    
//	    driver.close();
	    
	    //switchtab(1); //it iterate 1time and go to agian main window
	    
	    
	    System.out.println("again parent window" + driver.getTitle());
		
		
		
	}
	//if i give index 1--> main window
	//if i give index 2--> child window
	public static void switchtab(Set<String> parentwindow) {
		
	//	String open=null;
	//	Set<String> s = driver.getWindowHandles();
	  //Iterator<String> it=s.iterator();
		for(String windowHandles: driver.getWindowHandles()) {
			if(!parentwindow.contains(windowHandles)) {
				driver.switchTo().window(windowHandles);
			}
//		for(int i = 1; i <= index; i++) {
			//open=it.next();
		}
	//driver.switchTo().window(open);
		
	}
	
//for stringwindow
}

