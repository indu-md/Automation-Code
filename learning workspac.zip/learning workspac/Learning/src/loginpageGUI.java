import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class loginpageGUI implements ActionListener {

	public static void main(String[] args) {
		
		JFrame frame=new JFrame();
		JPanel panel=new JPanel();
		frame.setSize(400,200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.add(panel);
		
		panel.setLayout(null);
		
		JLabel label=new JLabel("User");
		label.setBounds(10,20,80,20);
		panel.add(label);
		
		JTextField usertext=new JTextField();
		usertext.setBounds(100, 20, 165, 25);
		panel.add(usertext);
		
		JLabel label2=new JLabel("password");
		label2.setBounds(10, 50, 80, 20);
		panel.add(label2);
		
		JPasswordField pwdtxt=new JPasswordField();
		pwdtxt.setBounds(100, 50, 165, 25);
		panel.add(pwdtxt);
		
		JButton button =new JButton("Login");
		button.setBounds(10, 80, 80, 25);
		button.addActionListener(new GUI());
		panel.add(button);
		
		JLabel success= new JLabel("");
		success.setBounds(10, 110, 300, 25);
		panel.add(success);
		
		frame.setVisible(true);
	

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("Button Clicked");
		
	}

}
