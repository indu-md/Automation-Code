
public class recursion {

	public static void main(String[] args) {
		hello(5);

	}
		
	public static void hello(int n) {
		if(n==0)
			{System.out.println("hello");}
		else {
			System.out.println("done");
		n--;
		hello(n);
	}}
}
