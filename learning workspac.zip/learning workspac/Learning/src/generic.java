import java.util.HashMap;
import java.util.Map;



public class generic {

	public static void main(String[] args) {
		
		info i =new info();
		System.out.println("name:" +i.name);
		System.out.println("id: " + i.id);
		System.out.println("address" + i.address);
		

	}
}
	 class info
	{
		public String name="indu";
		public int id = 12;
		public String address = "t park street";
		
	}
	
	

