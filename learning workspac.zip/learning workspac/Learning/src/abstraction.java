
abstract class Dog{   //abstract class
	
	String breed;
	
	public void bark() {
		System.out.println("owww owww!!!");
	}
	
	public abstract void poop(); //abstract method can not be implemented(do not specify a body!!)
}

class chowchow extends Dog{
	
	public void poop() {
		System.out.println("dog pooped");
	}
	
}

public class abstraction {

	public static void main(String[] args) {
		chowchow c=new chowchow();
		c.bark();
		c.poop();
		

	}

}
